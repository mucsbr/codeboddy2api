# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

CB2API is a CodeBuddy API proxy system that provides OpenAI-compatible and Anthropic-compatible endpoints for CodeBuddy services. The system includes account management, token rotation, and API format conversion capabilities.

## Architecture

### Core Services

1. **Main Service** (`main.py`) - Primary CodeBuddy API proxy (port 8000)
   - Handles OpenAI-compatible chat completions
   - Manages CodeBuddy account token rotation
   - Implements streaming and non-streaming responses

2. **Format Proxy** (`format_proxy.py`) - API format converter (port 8181)
   - Converts between OpenAI and Anthropic API formats
   - Handles bidirectional format conversion
   - Supports streaming response conversion

3. **Server** (`server.py`) - Alternative server implementation
   - Similar functionality to main.py with enhanced features
   - Includes comprehensive configuration management

### Key Components

- **ConfigManager**: Handles loading and managing:
  - Account tokens from `codebuddy_accounts.txt`
  - Model mappings from `models.json`
  - API keys from `client.json`

- **Token Management**: Round-robin token rotation system for load balancing across multiple CodeBuddy accounts

- **Format Converters**: Bidirectional conversion between OpenAI and Anthropic API formats

## Common Commands

### Development

```bash
# Install dependencies
pip install -r requirements.txt

# Start both services
./start_services.sh

# Start main service only
python3 main.py

# Start format proxy only
python3 format_proxy.py

# Test single account token
python3 test_token.py

# Get tokens for all accounts
./get_tokens.sh

# Get tokens for specific number of accounts
./get_tokens.sh 5
```

### Docker

```bash
# Build image
docker build -t cb2api .

# Run with docker-compose
docker-compose up
```

### Account Management

```bash
# Register new accounts
./batch_register.sh

# Manage tokens concurrently
python3 run_concurrent_tokens.py
```

## Configuration Files

### Required Files

- `codebuddy_accounts.txt` - Account pool with format:
  ```
  email|password|created_at|platform|access_token|refresh_token|token_expires|refresh_expires
  ```

- `models.json` - Model mapping configuration
- `client.json` - API keys for client authentication

### Environment Variables

- `BACKEND_TYPE` - Backend type (openai/anthropic/codebuddy)
- `BACKEND_BASE_URL` - Backend service URL
- `PROXY_PORT` - Proxy service port (default: 8181)
- `LOG_LEVEL` - Logging level (default: INFO)

## API Endpoints

### Main Service (port 8000)
- `POST /v1/chat/completions` - OpenAI-compatible chat completions
- `GET /v1/models` - List available models
- `GET /` - Health check

### Format Proxy (port 8181)
- `POST /v1/chat/completions` - OpenAI format endpoint
- `POST /v1/messages` - Anthropic format endpoint
- `POST /v1/messages/count_tokens` - Token counting (Anthropic only)
- `GET /v1/models` - Model listing
- `GET /` - Health check

## Development Notes

### JSON Parsing
The system includes enhanced JSON parsing with detailed error logging in `safe_json_loads()` function. It handles:
- UTF-8 encoding issues
- BOM removal
- Partial JSON recovery
- Detailed error diagnostics

### Streaming Support
Both services support streaming responses with proper SSE (Server-Sent Events) formatting and conversion between OpenAI and Anthropic streaming formats.

### Error Handling
Comprehensive error handling with detailed logging for debugging API format conversion issues and account management problems.

### Token Rotation
Automatic token rotation across multiple CodeBuddy accounts to distribute load and avoid rate limiting.

## Logging

Logs are written to:
- `logs/main.log` - Main service logs
- `logs/format_proxy.log` - Format proxy logs
- `codebuddy_proxy.log` - General proxy logs
- Various token management logs with timestamps

## Troubleshooting

### Common Issues

1. **JSON Parsing Errors**: Check request body encoding and format
2. **Token Expiration**: Run token refresh scripts
3. **Service Startup**: Check port availability and dependencies
4. **Account Issues**: Verify account file format and token validity

### Debug Commands

```bash
# View real-time logs
tail -f logs/main.log
tail -f logs/format_proxy.log

# Test API endpoints
curl -X POST http://localhost:8000/v1/chat/completions
curl -X POST http://localhost:8181/v1/messages

# Check service status
curl http://localhost:8000/
curl http://localhost:8181/
```