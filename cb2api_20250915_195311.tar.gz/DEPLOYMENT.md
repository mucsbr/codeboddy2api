# CB2API 部署说明

## 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 配置文件
- 确保 `codebuddy_accounts.txt` 包含有效的账号信息
- 检查 `models.json` 中的模型映射配置
- 验证 `client.json` 中的API密钥

### 3. 启动服务

#### 方式一：使用启动脚本（推荐）
```bash
chmod +x start_services.sh
./start_services.sh
```

#### 方式二：手动启动
```bash
# 启动主服务 (端口 8000)
python3 main.py &

# 启动格式代理服务 (端口 8181)
python3 format_proxy.py &
```

#### 方式三：使用Docker
```bash
docker build -t cb2api .
docker-compose up
```

### 4. 测试服务
```bash
# 测试主服务
curl http://localhost:8000/

# 测试代理服务
curl http://localhost:8181/

# 测试token
python3 test_token.py
```

## 服务端点

### 主服务 (端口 8000)
- `POST /v1/chat/completions` - OpenAI兼容的聊天完成
- `GET /v1/models` - 获取可用模型列表
- `GET /` - 健康检查

### 格式代理服务 (端口 8181)
- `POST /v1/chat/completions` - OpenAI格式端点
- `POST /v1/messages` - Anthropic格式端点
- `POST /v1/messages/count_tokens` - Token计数（仅Anthropic）
- `GET /v1/models` - 模型列表
- `GET /` - 健康检查

## 配置文件说明

### codebuddy_accounts.txt
格式：`email|password|created_at|platform|access_token|refresh_token|token_expires|refresh_expires`

### models.json
模型映射配置，将外部模型名映射到内部模型名

### client.json
客户端API密钥列表

## 故障排除

### 查看日志
```bash
tail -f logs/main.log
tail -f logs/format_proxy.log
tail -f codebuddy_proxy.log
```

### 常见问题
1. **端口被占用**: 修改代码中的端口号或停止占用端口的进程
2. **Token过期**: 运行 `./get_tokens.sh` 刷新token
3. **依赖缺失**: 确保所有requirements.txt中的包都已安装
4. **配置文件错误**: 检查JSON格式和文件权限

## 工具脚本

- `test_token.py` - 测试单个账号token
- `get_tokens.sh` - 批量获取账号token
- `run_concurrent_tokens.py` - 并发token管理

